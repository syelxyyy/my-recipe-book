# My Recipe Book 🍪

Website buku resep digital bertema **brown vintage**, menggunakan HTML, CSS, dan JavaScript murni.

## Fitur
- Koleksi resep makanan dan minuman Indonesia serta internasional
- Pencarian berdasarkan nama resep, kategori, dan bahan
- Filter kategori dan pengurutan
- Detail bahan dan langkah memasak
- Simpan/hapus resep favorit
- Tambah resep sendiri
- Data favorit dan resep tambahan disimpan di `localStorage` browser

## Cara menjalankan
1. Unduh dan ekstrak folder proyek.
2. Buka `index.html` di browser, atau gunakan ekstensi Live Server di VS Code.

## Cara mengunggah ke GitHub Pages
1. Buat repository baru di GitHub, misalnya `my-recipe-book`.
2. Unggah `index.html`, `style.css`, `script.js`, dan `README.md` ke root repository.
3. Buka **Settings → Pages**.
4. Pada bagian Build and deployment, pilih **Deploy from a branch**.
5. Pilih branch `main` dan folder `/ (root)`, lalu klik **Save**.
6. Tunggu proses publikasi selesai. GitHub akan menampilkan alamat website.

## Catatan
- Resep tambahan dan favorit disimpan di browser/perangkat yang digunakan, bukan tersinkron otomatis ke akun GitHub.
- Google Fonts membutuhkan koneksi internet; jika offline, website memakai font cadangan.
