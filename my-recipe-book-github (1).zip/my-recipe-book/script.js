const starterRecipes = [
  {id:"r1",name:"Nasi Goreng Kampung",type:"Makanan",origin:"Indonesia",time:20,emoji:"🍛",description:"Nasi goreng sederhana dengan bumbu gurih dan aroma khas rumahan.",ingredients:["2 piring nasi putih dingin","2 siung bawang putih","3 siung bawang merah","2 buah cabai (sesuai selera)","1 butir telur","1 sdm kecap manis","Garam dan merica secukupnya","Minyak untuk menumis"],steps:["Haluskan bawang merah, bawang putih, dan cabai.","Panaskan sedikit minyak, lalu tumis bumbu hingga harum.","Masukkan telur dan orak-arik hingga matang.","Tambahkan nasi, kecap manis, garam, dan merica.","Aduk hingga semua tercampur rata dan sajikan hangat."],notes:"Gunakan nasi yang sudah dingin agar teksturnya tidak terlalu lembek."},
  {id:"r2",name:"Sate Ayam",type:"Makanan",origin:"Indonesia",time:45,emoji:"🍢",description:"Potongan ayam berbumbu yang disajikan dengan saus kacang gurih.",ingredients:["300 gram dada ayam, potong dadu","2 sdm kecap manis","1 sdm minyak","150 gram kacang tanah goreng","2 siung bawang putih","2 buah cabai merah","Garam dan gula secukupnya","Air secukupnya"],steps:["Campurkan ayam dengan sedikit kecap dan minyak, lalu diamkan 15 menit.","Tusuk potongan ayam menggunakan tusuk sate.","Haluskan kacang, bawang putih, cabai, garam, dan gula.","Tambahkan air sedikit demi sedikit pada bumbu kacang.","Panggang sate sambil dibolak-balik hingga matang.","Sajikan sate dengan saus kacang dan kecap manis."],notes:"Pastikan ayam matang sempurna sebelum disajikan."},
  {id:"r3",name:"Pisang Goreng",type:"Makanan",origin:"Indonesia",time:25,emoji:"🍌",description:"Camilan renyah di luar dan lembut manis di bagian dalam.",ingredients:["5 buah pisang kepok","100 gram tepung terigu","1 sdm gula","Sejumput garam","120 ml air","Minyak untuk menggoreng"],steps:["Kupas pisang dan belah sesuai selera.","Campurkan tepung, gula, garam, dan air hingga menjadi adonan.","Celupkan pisang ke dalam adonan.","Goreng dalam minyak panas dengan api sedang hingga keemasan.","Angkat dan tiriskan sebelum disajikan."],notes:"Nikmat disantap selagi hangat."},
  {id:"r4",name:"Rendang Sederhana",type:"Makanan",origin:"Indonesia",time:120,emoji:"🍲",description:"Olahan daging kaya rempah dengan kuah santan yang dimasak perlahan.",ingredients:["500 gram daging sapi","500 ml santan","6 siung bawang merah","4 siung bawang putih","3 cabai merah","2 cm jahe","2 cm lengkuas","1 batang serai","Garam secukupnya"],steps:["Haluskan bawang merah, bawang putih, cabai, dan jahe.","Masukkan bumbu, daging, santan, serai, dan lengkuas ke dalam panci.","Masak dengan api kecil sambil sesekali diaduk.","Lanjutkan memasak hingga daging empuk dan bumbu mengental.","Koreksi rasa dan sajikan."],notes:"Masak perlahan agar bumbu meresap dan santan tidak mudah pecah."},
  {id:"r5",name:"Es Teh Lemon",type:"Minuman",origin:"Internasional",time:10,emoji:"🍋",description:"Minuman teh dingin dengan rasa lemon yang segar.",ingredients:["1 kantong teh hitam","250 ml air panas","1/2 buah lemon","2 sdm gula atau madu","Es batu secukupnya"],steps:["Seduh teh dengan air panas selama 3–5 menit.","Tambahkan gula atau madu, lalu aduk hingga larut.","Diamkan hingga suhu ruang.","Tambahkan perasan lemon dan es batu.","Iris sedikit lemon untuk hiasan, lalu sajikan."],notes:"Atur rasa manis dan asam sesuai selera."},
  {id:"r6",name:"Jus Alpukat",type:"Minuman",origin:"Indonesia",time:10,emoji:"🥑",description:"Jus alpukat lembut yang cocok dinikmati saat cuaca hangat.",ingredients:["1 buah alpukat matang","150 ml susu cair","1–2 sdm gula atau madu","Es batu secukupnya"],steps:["Belah alpukat dan ambil daging buahnya.","Masukkan alpukat, susu, dan gula ke blender.","Proses hingga lembut dan tercampur rata.","Tuang ke gelas dan tambahkan es batu.","Sajikan segera."],notes:"Pilih alpukat yang matang agar rasanya lebih creamy."},
  {id:"r7",name:"Pancake Klasik",type:"Makanan",origin:"Internasional",time:20,emoji:"🥞",description:"Pancake empuk untuk sarapan, cocok disajikan dengan madu dan buah.",ingredients:["150 gram tepung terigu","1 sdm gula","1 sdt baking powder","1 butir telur","180 ml susu cair","2 sdm mentega cair"],steps:["Campurkan tepung, gula, dan baking powder.","Di wadah lain, kocok telur, susu, dan mentega cair.","Tuangkan bahan cair ke bahan kering, aduk secukupnya.","Panaskan wajan anti lengket dengan api kecil.","Tuang satu sendok sayur adonan; balik saat muncul gelembung.","Masak hingga kedua sisi keemasan."],notes:"Jangan mengaduk adonan terlalu lama agar pancake tetap lembut."},
  {id:"r8",name:"Spaghetti Aglio e Olio",type:"Makanan",origin:"Internasional",time:25,emoji:"🍝",description:"Pasta sederhana dengan bawang putih, minyak zaitun, dan sedikit cabai.",ingredients:["200 gram spaghetti","3 siung bawang putih, iris tipis","2 sdm minyak zaitun","Cabai kering secukupnya","Garam dan lada","Daun parsley (opsional)"],steps:["Rebus spaghetti dalam air mendidih yang diberi garam hingga al dente.","Panaskan minyak zaitun dengan api kecil.","Tumis bawang putih dan cabai hingga harum, jangan sampai gosong.","Masukkan spaghetti dan sedikit air rebusannya.","Aduk hingga saus melapisi pasta, lalu bumbui dengan lada.","Taburi parsley dan sajikan."],notes:"Sisihkan sedikit air rebusan pasta untuk membantu saus menyatu."},
  {id:"r9",name:"Cokelat Panas",type:"Minuman",origin:"Internasional",time:8,emoji:"☕",description:"Minuman cokelat hangat yang lembut dan menenangkan.",ingredients:["250 ml susu cair","2 sdm bubuk kakao","1–2 sdm gula","Sejumput garam","Marshmallow (opsional)"],steps:["Campurkan bubuk kakao, gula, dan sedikit susu hingga menjadi pasta.","Panaskan sisa susu dengan api kecil.","Masukkan pasta cokelat dan aduk hingga larut.","Tambahkan sejumput garam, lalu aduk rata.","Tuang ke cangkir dan beri marshmallow jika suka."],notes:"Jangan biarkan susu mendidih terlalu lama."}
];

const STORAGE_KEY = "myRecipeBook_custom_v1";
const FAVORITE_KEY = "myRecipeBook_favorites_v1";
let customRecipes = readStorage(STORAGE_KEY, []);
let favorites = readStorage(FAVORITE_KEY, []);
let activeFilter = "Semua";
let toastTimer;

function readStorage(key, fallback) {
  try { const value = JSON.parse(localStorage.getItem(key)); return value ?? fallback; }
  catch { return fallback; }
}
function saveStorage(key, value) { localStorage.setItem(key, JSON.stringify(value)); }
function allRecipes() { return [...starterRecipes, ...customRecipes]; }
function escapeHTML(value) {
  return String(value).replace(/[&<>"']/g, char => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[char]));
}
function cardTemplate(recipe) {
  const saved = favorites.includes(recipe.id);
  const artClass = recipe.type === "Minuman" ? "drink" : (recipe.origin === "Internasional" ? "international" : "");
  const dessertClass = /pancake|pisang|cokelat/i.test(recipe.name) ? " dessert" : "";
  return `<article class="recipe-card">
    <div class="card-art ${artClass}${dessertClass}">
      <span class="card-category">${escapeHTML(recipe.type)} · ${escapeHTML(recipe.origin)}</span>
      <span class="card-emoji">${escapeHTML(recipe.emoji || "🍽️")}</span>
      <button class="favorite-button ${saved ? "saved" : ""}" data-favorite="${escapeHTML(recipe.id)}" aria-label="${saved ? "Hapus dari" : "Tambah ke"} favorit">${saved ? "♥" : "♡"}</button>
    </div>
    <div class="card-body">
      <div class="card-meta"><span>◷ ${Number(recipe.time)} menit</span><span>✦ Resep pilihan</span></div>
      <h3>${escapeHTML(recipe.name)}</h3>
      <p class="card-description">${escapeHTML(recipe.description || "Resep pilihan untuk dicoba di rumah.")}</p>
      <div class="card-bottom"><span class="origin-label">${escapeHTML(recipe.origin)}</span><button class="detail-link" data-detail="${escapeHTML(recipe.id)}">Lihat resep →</button></div>
    </div>
  </article>`;
}
function getFilteredRecipes() {
  const query = document.getElementById("search-input").value.trim().toLowerCase();
  let list = allRecipes().filter(recipe => {
    const matchesFilter = activeFilter === "Semua" || recipe.type === activeFilter || recipe.origin === activeFilter;
    const searchable = [recipe.name, recipe.description, recipe.origin, recipe.type, ...(recipe.ingredients || [])].join(" ").toLowerCase();
    return matchesFilter && searchable.includes(query);
  });
  const sort = document.getElementById("sort-select").value;
  if (sort === "az") list.sort((a,b) => a.name.localeCompare(b.name, "id"));
  if (sort === "time") list.sort((a,b) => Number(a.time) - Number(b.time));
  return list;
}
function render() {
  const list = getFilteredRecipes();
  document.getElementById("recipe-grid").innerHTML = list.map(cardTemplate).join("");
  document.getElementById("recipe-count").textContent = allRecipes().length;
  document.getElementById("empty-state").classList.toggle("hidden", list.length !== 0);
  const favoriteList = allRecipes().filter(recipe => favorites.includes(recipe.id));
  document.getElementById("favorite-grid").innerHTML = favoriteList.map(cardTemplate).join("");
  document.getElementById("favorite-empty").classList.toggle("hidden", favoriteList.length !== 0);
}
function showToast(message) {
  const toast = document.getElementById("toast");
  toast.textContent = message; toast.classList.add("show");
  clearTimeout(toastTimer); toastTimer = setTimeout(() => toast.classList.remove("show"), 2400);
}
function toggleFavorite(id) {
  favorites = favorites.includes(id) ? favorites.filter(item => item !== id) : [...favorites, id];
  saveStorage(FAVORITE_KEY, favorites); render();
  showToast(favorites.includes(id) ? "Resep ditambahkan ke favorit ♡" : "Resep dihapus dari favorit");
}
function openDetail(id) {
  const recipe = allRecipes().find(item => item.id === id);
  if (!recipe) return;
  const ingredients = (recipe.ingredients || []).map(item => `<li>${escapeHTML(item)}</li>`).join("");
  const steps = (recipe.steps || []).map(item => `<li>${escapeHTML(item)}</li>`).join("");
  document.getElementById("detail-content").innerHTML = `
    <div class="detail-hero">
      <div class="detail-emoji">${escapeHTML(recipe.emoji || "🍽️")}</div>
      <div><span class="eyebrow">${escapeHTML(recipe.type)} · ${escapeHTML(recipe.origin)}</span><h2 id="detail-title">${escapeHTML(recipe.name)}</h2><p>◷ ${Number(recipe.time)} menit · resep rumahan</p></div>
    </div>
    <div class="detail-columns">
      <section><h3>Bahan-bahan</h3><ul>${ingredients}</ul></section>
      <section><h3>Cara Membuat</h3><ol>${steps}</ol></section>
    </div>
    ${recipe.notes ? `<p class="detail-note"><strong>Catatan dapur:</strong> ${escapeHTML(recipe.notes)}</p>` : ""}
    <button class="button button-dark" data-favorite="${escapeHTML(recipe.id)}">${favorites.includes(recipe.id) ? "♥ Hapus dari Favorit" : "♡ Simpan ke Favorit"}</button>`;
  document.getElementById("detail-modal").classList.remove("hidden");
}
function closeModals() { document.querySelectorAll(".modal-backdrop").forEach(modal => modal.classList.add("hidden")); }
function openAddModal() { document.getElementById("add-modal").classList.remove("hidden"); }

document.addEventListener("click", event => {
  const favoriteButton = event.target.closest("[data-favorite]");
  const detailButton = event.target.closest("[data-detail]");
  if (favoriteButton) toggleFavorite(favoriteButton.dataset.favorite);
  if (detailButton) openDetail(detailButton.dataset.detail);
  if (event.target.matches("[data-close]") || event.target.classList.contains("modal-backdrop")) closeModals();
});
document.getElementById("filter-row").addEventListener("click", event => {
  const chip = event.target.closest("[data-filter]");
  if (!chip) return;
  activeFilter = chip.dataset.filter;
  document.querySelectorAll(".filter-chip").forEach(item => item.classList.toggle("active", item === chip));
  render();
});
document.getElementById("search-input").addEventListener("input", render);
document.getElementById("sort-select").addEventListener("change", render);
document.getElementById("reset-search").addEventListener("click", () => {
  document.getElementById("search-input").value = "";
  activeFilter = "Semua";
  document.querySelectorAll(".filter-chip").forEach(chip => chip.classList.toggle("active", chip.dataset.filter === "Semua"));
  render();
});
document.getElementById("open-add").addEventListener("click", openAddModal);
document.getElementById("mobile-menu").addEventListener("click", () => document.querySelector(".desktop-nav").classList.toggle("open"));
document.querySelectorAll(".nav-link").forEach(link => link.addEventListener("click", () => document.querySelector(".desktop-nav").classList.remove("open")));
document.getElementById("recipe-form").addEventListener("submit", event => {
  event.preventDefault();
  const form = new FormData(event.currentTarget);
  const splitLines = value => String(value).split("\n").map(line => line.trim()).filter(Boolean);
  const recipe = {
    id: "custom-" + Date.now(),
    name: form.get("name").trim(),
    type: form.get("type"),
    origin: form.get("origin"),
    time: Number(form.get("time")),
    emoji: form.get("emoji").trim() || "🍽️",
    description: "Resep buatan sendiri yang ditambahkan ke buku resep.",
    ingredients: splitLines(form.get("ingredients")),
    steps: splitLines(form.get("steps")),
    notes: form.get("notes").trim()
  };
  if (!recipe.ingredients.length || !recipe.steps.length || !recipe.time || recipe.time < 1) {
    showToast("Lengkapi bahan, langkah, dan waktu memasak, ya."); return;
  }
  customRecipes.push(recipe);
  saveStorage(STORAGE_KEY, customRecipes);
  event.currentTarget.reset();
  closeModals(); activeFilter = "Semua";
  document.querySelectorAll(".filter-chip").forEach(chip => chip.classList.toggle("active", chip.dataset.filter === "Semua"));
  document.getElementById("search-input").value = "";
  render(); showToast("Resep barumu berhasil disimpan! ✨");
  document.getElementById("koleksi").scrollIntoView({behavior:"smooth"});
});
document.addEventListener("keydown", event => { if (event.key === "Escape") closeModals(); });
document.getElementById("year").textContent = new Date().getFullYear();
render();
